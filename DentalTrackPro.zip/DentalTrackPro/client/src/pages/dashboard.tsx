import { StatsCard } from "@/components/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Calendar, CheckCircle, TrendingUp, Clock, Activity } from "lucide-react";
import { AppointmentCard } from "@/components/appointment-card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts";

//todo: remove mock functionality
const mockAppointmentsToday = [
  {
    id: "1",
    patientName: "Rajesh Kumar",
    doctorName: "Dr. Sharma",
    treatmentType: "Root Canal",
    date: new Date(),
    status: "upcoming" as const,
  },
  {
    id: "2",
    patientName: "Priya Sharma",
    doctorName: "Dr. Reddy",
    treatmentType: "Teeth Cleaning",
    date: new Date(),
    status: "upcoming" as const,
  },
];

const chartData = [
  { month: "Jan", appointments: 45 },
  { month: "Feb", appointments: 52 },
  { month: "Mar", appointments: 48 },
  { month: "Apr", appointments: 61 },
  { month: "May", appointments: 55 },
  { month: "Jun", appointments: 67 },
];

const treatmentData = [
  { treatment: "Cleaning", count: 120 },
  { treatment: "Root Canal", count: 45 },
  { treatment: "Extraction", count: 32 },
  { treatment: "Filling", count: 89 },
  { treatment: "Checkup", count: 156 },
];

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold">Dashboard</h1>
        <p className="text-muted-foreground mt-1">Welcome to CVS Dental Care Management System</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Total Patients"
          value="1,234"
          icon={Users}
          trend={{ value: "+12% from last month", isPositive: true }}
        />
        <StatsCard
          title="Today's Appointments"
          value="18"
          icon={Calendar}
          trend={{ value: "+3 from yesterday", isPositive: true }}
        />
        <StatsCard
          title="Completed This Month"
          value="156"
          icon={CheckCircle}
          trend={{ value: "+8% this month", isPositive: true }}
        />
        <StatsCard
          title="Monthly Revenue"
          value="₹2.4L"
          icon={TrendingUp}
          trend={{ value: "+15% from last month", isPositive: true }}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
            <CardTitle className="text-base">Today's Appointments</CardTitle>
            <Link href="/appointments">
              <Button variant="outline" size="sm" data-testid="button-view-all-appointments">
                View All
              </Button>
            </Link>
          </CardHeader>
          <CardContent className="space-y-4">
            {mockAppointmentsToday.map((apt) => (
              <AppointmentCard key={apt.id} {...apt} />
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Link href="/patients">
              <Button className="w-full justify-start" variant="outline" data-testid="button-add-patient">
                <Users className="h-4 w-4 mr-2" />
                Add New Patient
              </Button>
            </Link>
            <Link href="/appointments">
              <Button className="w-full justify-start" variant="outline" data-testid="button-schedule-appointment">
                <Calendar className="h-4 w-4 mr-2" />
                Schedule Appointment
              </Button>
            </Link>
            <Link href="/patients">
              <Button className="w-full justify-start" variant="outline" data-testid="button-view-patients">
                <Activity className="h-4 w-4 mr-2" />
                View All Patients
              </Button>
            </Link>
            <Link href="/appointments">
              <Button className="w-full justify-start" variant="outline" data-testid="button-calendar">
                <Clock className="h-4 w-4 mr-2" />
                View Calendar
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Appointments Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="month" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip />
                <Line type="monotone" dataKey="appointments" stroke="hsl(var(--primary))" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Treatment Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={treatmentData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="treatment" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip />
                <Bar dataKey="count" fill="hsl(var(--primary))" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
