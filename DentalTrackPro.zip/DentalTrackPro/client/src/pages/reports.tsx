import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, FileText, TrendingUp, Users } from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";

//todo: remove mock functionality
const monthlyData = [
  { month: "Jan", revenue: 180000, patients: 45 },
  { month: "Feb", revenue: 210000, patients: 52 },
  { month: "Mar", revenue: 195000, patients: 48 },
  { month: "Apr", revenue: 245000, patients: 61 },
  { month: "May", revenue: 220000, patients: 55 },
  { month: "Jun", revenue: 270000, patients: 67 },
];

const treatmentTypeData = [
  { name: "Cleaning", value: 120, color: "hsl(var(--chart-1))" },
  { name: "Root Canal", value: 45, color: "hsl(var(--chart-2))" },
  { name: "Extraction", value: 32, color: "hsl(var(--chart-3))" },
  { name: "Filling", value: 89, color: "hsl(var(--chart-4))" },
  { name: "Checkup", value: 156, color: "hsl(var(--chart-5))" },
];

export default function Reports() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold">Reports</h1>
          <p className="text-muted-foreground mt-1">Analytics and insights</p>
        </div>
        <Button data-testid="button-export-report">
          <Download className="h-4 w-4 mr-2" />
          Export Report
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">₹13.2L</div>
            <p className="text-xs text-green-600 dark:text-green-400 mt-1">+18% from last period</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">New Patients</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">328</div>
            <p className="text-xs text-green-600 dark:text-green-400 mt-1">+12% from last period</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Treatments</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">442</div>
            <p className="text-xs text-green-600 dark:text-green-400 mt-1">+8% from last period</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Monthly Revenue & Patient Growth</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="month" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip />
                <Legend />
                <Bar dataKey="revenue" fill="hsl(var(--primary))" name="Revenue (₹)" />
                <Bar dataKey="patients" fill="hsl(var(--chart-2))" name="Patients" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Treatment Type Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={treatmentTypeData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={(entry) => entry.name}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {treatmentTypeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Quick Reports</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button variant="outline" className="w-full justify-start" data-testid="button-patient-report">
            <FileText className="h-4 w-4 mr-2" />
            Generate Patient Report
          </Button>
          <Button variant="outline" className="w-full justify-start" data-testid="button-appointment-report">
            <FileText className="h-4 w-4 mr-2" />
            Generate Appointment Report
          </Button>
          <Button variant="outline" className="w-full justify-start" data-testid="button-revenue-report">
            <FileText className="h-4 w-4 mr-2" />
            Generate Revenue Report
          </Button>
          <Button variant="outline" className="w-full justify-start" data-testid="button-treatment-report">
            <FileText className="h-4 w-4 mr-2" />
            Generate Treatment Summary
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
