import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Bell, User, Lock, Building, Mail } from "lucide-react";

export default function Settings() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold">Settings</h1>
        <p className="text-muted-foreground mt-1">Manage your clinic settings and preferences</p>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Building className="h-5 w-5 text-primary" />
              <CardTitle>Clinic Information</CardTitle>
            </div>
            <CardDescription>Update your clinic details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="clinic-name">Clinic Name</Label>
                <Input id="clinic-name" defaultValue="CVS Dental Care" data-testid="input-clinic-name" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input id="location" defaultValue="Hayathnagar" data-testid="input-location" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" defaultValue="7901403030" data-testid="input-clinic-phone" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" defaultValue="cvsdentalcare@gmail.com" data-testid="input-clinic-email" />
              </div>
            </div>
            <Button data-testid="button-save-clinic-info">Save Changes</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <User className="h-5 w-5 text-primary" />
              <CardTitle>User Profile</CardTitle>
            </div>
            <CardDescription>Manage your personal information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="user-name">Full Name</Label>
                <Input id="user-name" defaultValue="Dr. Admin" data-testid="input-user-name" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="user-email">Email</Label>
                <Input id="user-email" type="email" defaultValue="admin@cvsdentalcare.com" data-testid="input-user-email" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="role">Role</Label>
                <Input id="role" defaultValue="Admin" disabled data-testid="input-role" />
              </div>
            </div>
            <Button data-testid="button-save-profile">Update Profile</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Lock className="h-5 w-5 text-primary" />
              <CardTitle>Change Password</CardTitle>
            </div>
            <CardDescription>Update your account password</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="current-password">Current Password</Label>
              <Input id="current-password" type="password" data-testid="input-current-password" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-password">New Password</Label>
              <Input id="new-password" type="password" data-testid="input-new-password" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirm-password">Confirm New Password</Label>
              <Input id="confirm-password" type="password" data-testid="input-confirm-password" />
            </div>
            <Button data-testid="button-change-password">Change Password</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Bell className="h-5 w-5 text-primary" />
              <CardTitle>Notifications</CardTitle>
            </div>
            <CardDescription>Manage notification preferences</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Email Notifications</p>
                <p className="text-sm text-muted-foreground">Receive appointment reminders via email</p>
              </div>
              <Switch defaultChecked data-testid="switch-email-notifications" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">SMS Notifications</p>
                <p className="text-sm text-muted-foreground">Receive appointment reminders via SMS</p>
              </div>
              <Switch defaultChecked data-testid="switch-sms-notifications" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Birthday Reminders</p>
                <p className="text-sm text-muted-foreground">Get notified of patient birthdays</p>
              </div>
              <Switch data-testid="switch-birthday-reminders" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Recall Visit Reminders</p>
                <p className="text-sm text-muted-foreground">Automatic reminders for follow-up visits</p>
              </div>
              <Switch defaultChecked data-testid="switch-recall-reminders" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Mail className="h-5 w-5 text-primary" />
              <CardTitle>WhatsApp & SMS Reminders (Coming Soon)</CardTitle>
            </div>
            <CardDescription>Send automated appointment reminders via WhatsApp and SMS</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-primary/5 border border-primary/20 rounded-md p-4">
              <h4 className="font-semibold text-sm mb-2">Integration Ready</h4>
              <p className="text-sm text-muted-foreground mb-3">
                Your CRM is ready for WhatsApp and SMS integration using Twilio. Once configured, you'll be able to:
              </p>
              <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                <li>Send appointment reminders automatically</li>
                <li>Send birthday wishes to patients</li>
                <li>Notify patients about recall visits</li>
                <li>Communicate through WhatsApp Business API</li>
              </ul>
            </div>
            <p className="text-xs text-muted-foreground">
              <strong>Note:</strong> To enable this feature, you'll need to set up a Twilio account and configure the integration. This will be available in the next phase of development.
            </p>
            <div className="flex gap-2">
              <Button variant="secondary" disabled data-testid="button-configure-whatsapp">
                Configure WhatsApp
              </Button>
              <Button variant="secondary" disabled data-testid="button-configure-sms">
                Configure SMS
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
