import { useState } from "react";
import { SearchBar } from "@/components/search-bar";
import { Button } from "@/components/ui/button";
import { AppointmentCard } from "@/components/appointment-card";
import { AppointmentForm } from "@/components/appointment-form";
import { CalendarView } from "@/components/calendar-view";
import { Plus, List, CalendarDays } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { type InsertAppointment } from "@shared/schema";

//todo: remove mock functionality
const mockAppointments = [
  {
    id: "1",
    patientId: "1",
    patientName: "Rajesh Kumar",
    doctorName: "Dr. Sharma",
    treatmentType: "Root Canal",
    date: new Date(Date.now() + 86400000),
    status: "upcoming" as const,
    notes: "First session of root canal treatment",
  },
  {
    id: "2",
    patientId: "2",
    patientName: "Priya Sharma",
    doctorName: "Dr. Reddy",
    treatmentType: "Teeth Cleaning",
    date: new Date(Date.now() - 86400000),
    status: "completed" as const,
    notes: "Regular dental checkup and cleaning",
  },
  {
    id: "3",
    patientId: "3",
    patientName: "Mohammed Ali",
    doctorName: "Dr. Patel",
    treatmentType: "Tooth Extraction",
    date: new Date(),
    status: "cancelled" as const,
    notes: "Patient requested cancellation",
  },
  {
    id: "4",
    patientId: "4",
    patientName: "Lakshmi Devi",
    doctorName: "Dr. Kumar",
    treatmentType: "Dental Filling",
    date: new Date(Date.now() + 172800000),
    status: "upcoming" as const,
  },
  {
    id: "5",
    patientId: "5",
    patientName: "Arjun Reddy",
    doctorName: "Dr. Sharma",
    treatmentType: "General Checkup",
    date: new Date(),
    status: "upcoming" as const,
  },
];

const calendarAppointments = mockAppointments.map((apt) => ({
  id: apt.id,
  time: new Date(apt.date).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
  patientName: apt.patientName,
  treatmentType: apt.treatmentType,
  status: apt.status,
}));

export default function Appointments() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddAppointmentOpen, setIsAddAppointmentOpen] = useState(false);
  const [view, setView] = useState<"list" | "calendar">("list");
  const [appointments] = useState(mockAppointments);

  const filteredAppointments = appointments.filter((appointment) =>
    appointment.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    appointment.doctorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    appointment.treatmentType.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddAppointment = (data: InsertAppointment) => {
    console.log("Adding appointment:", data);
    setIsAddAppointmentOpen(false);
  };

  const handleEdit = (id: string) => {
    console.log("Edit appointment:", id);
  };

  const handleDelete = (id: string) => {
    console.log("Delete appointment:", id);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold">Appointments</h1>
          <p className="text-muted-foreground mt-1">Schedule and manage appointments</p>
        </div>
        <Button onClick={() => setIsAddAppointmentOpen(true)} data-testid="button-add-new-appointment">
          <Plus className="h-4 w-4 mr-2" />
          New Appointment
        </Button>
      </div>

      <Tabs value={view} onValueChange={(v) => setView(v as any)} className="space-y-4">
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <SearchBar
            placeholder="Search by patient, doctor, or treatment..."
            onSearch={setSearchQuery}
            className="flex-1 max-w-md"
          />
          <TabsList>
            <TabsTrigger value="list" data-testid="tab-list-view">
              <List className="h-4 w-4 mr-2" />
              List
            </TabsTrigger>
            <TabsTrigger value="calendar" data-testid="tab-calendar-view">
              <CalendarDays className="h-4 w-4 mr-2" />
              Calendar
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="list" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredAppointments.map((appointment) => (
              <AppointmentCard
                key={appointment.id}
                {...appointment}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))}
          </div>

          {filteredAppointments.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No appointments found matching your search.</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="calendar">
          <CalendarView appointments={calendarAppointments} />
        </TabsContent>
      </Tabs>

      <Dialog open={isAddAppointmentOpen} onOpenChange={setIsAddAppointmentOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Schedule New Appointment</DialogTitle>
          </DialogHeader>
          <AppointmentForm
            onSubmit={handleAddAppointment}
            onCancel={() => setIsAddAppointmentOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
