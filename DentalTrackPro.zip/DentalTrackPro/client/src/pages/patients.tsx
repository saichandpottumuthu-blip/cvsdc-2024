import { useState } from "react";
import { SearchBar } from "@/components/search-bar";
import { Button } from "@/components/ui/button";
import { PatientCard } from "@/components/patient-card";
import { PatientForm } from "@/components/patient-form";
import { Plus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { type InsertPatient } from "@shared/schema";

//todo: remove mock functionality
const mockPatients = [
  {
    id: "1",
    patientId: "CVS00001",
    name: "Rajesh Kumar",
    age: 35,
    gender: "Male",
    phone: "9876543210",
    email: "rajesh.kumar@email.com",
    address: "123 MG Road, Hayathnagar",
  },
  {
    id: "2",
    patientId: "CVS00002",
    name: "Priya Sharma",
    age: 28,
    gender: "Female",
    phone: "9123456789",
    email: "priya.s@email.com",
    address: "456 LB Nagar, Hyderabad",
  },
  {
    id: "3",
    patientId: "CVS00003",
    name: "Mohammed Ali",
    age: 42,
    gender: "Male",
    phone: "9988776655",
    email: "mohammed.ali@email.com",
    address: "789 Koti, Hyderabad",
  },
  {
    id: "4",
    patientId: "CVS00004",
    name: "Lakshmi Devi",
    age: 55,
    gender: "Female",
    phone: "9765432109",
    email: "lakshmi.devi@email.com",
    address: "321 Dilsukhnagar, Hyderabad",
  },
  {
    id: "5",
    patientId: "CVS00005",
    name: "Arjun Reddy",
    age: 31,
    gender: "Male",
    phone: "9567891234",
    email: "arjun.r@email.com",
    address: "654 Kukatpally, Hyderabad",
  },
  {
    id: "6",
    patientId: "CVS00006",
    name: "Sneha Patel",
    age: 24,
    gender: "Female",
    phone: "9234567890",
    email: "sneha.patel@email.com",
    address: "987 Madhapur, Hyderabad",
  },
];

export default function Patients() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddPatientOpen, setIsAddPatientOpen] = useState(false);
  const [patients] = useState(mockPatients);

  const filteredPatients = patients.filter((patient) =>
    patient.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    patient.phone.includes(searchQuery) ||
    (patient.email && patient.email.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleAddPatient = (data: InsertPatient) => {
    console.log("Adding patient:", data);
    setIsAddPatientOpen(false);
  };

  const handleEdit = (id: string) => {
    console.log("Edit patient:", id);
  };

  const handleDelete = (id: string) => {
    console.log("Delete patient:", id);
  };

  const handleViewDetails = (id: string) => {
    console.log("View patient details:", id);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold">Patients</h1>
          <p className="text-muted-foreground mt-1">Manage patient profiles and records</p>
        </div>
        <Button onClick={() => setIsAddPatientOpen(true)} data-testid="button-add-new-patient">
          <Plus className="h-4 w-4 mr-2" />
          Add New Patient
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <SearchBar
          placeholder="Search by name, phone, or email..."
          onSearch={setSearchQuery}
          className="flex-1"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredPatients.map((patient) => (
          <PatientCard
            key={patient.id}
            {...patient}
            onEdit={handleEdit}
            onDelete={handleDelete}
            onViewDetails={handleViewDetails}
          />
        ))}
      </div>

      {filteredPatients.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No patients found matching your search.</p>
        </div>
      )}

      <Dialog open={isAddPatientOpen} onOpenChange={setIsAddPatientOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add New Patient</DialogTitle>
          </DialogHeader>
          <PatientForm
            onSubmit={handleAddPatient}
            onCancel={() => setIsAddPatientOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
