import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, User, Stethoscope, Edit, Trash2 } from "lucide-react";
import { format } from "date-fns";

interface AppointmentCardProps {
  id: string;
  patientName: string;
  doctorName: string;
  treatmentType: string;
  date: Date;
  status: "upcoming" | "completed" | "cancelled";
  notes?: string;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
}

const statusConfig = {
  upcoming: { label: "Upcoming", variant: "default" as const },
  completed: { label: "Completed", variant: "secondary" as const },
  cancelled: { label: "Cancelled", variant: "destructive" as const },
};

export function AppointmentCard({
  id,
  patientName,
  doctorName,
  treatmentType,
  date,
  status,
  notes,
  onEdit,
  onDelete,
}: AppointmentCardProps) {
  const statusInfo = statusConfig[status];

  return (
    <Card className="hover-elevate" data-testid={`card-appointment-${id}`}>
      <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0 pb-4">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <Badge variant={statusInfo.variant}>{statusInfo.label}</Badge>
          </div>
          <h3 className="font-semibold text-base">{treatmentType}</h3>
        </div>
        <div className="flex gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onEdit?.(id)}
            data-testid={`button-edit-appointment-${id}`}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onDelete?.(id)}
            data-testid={`button-delete-appointment-${id}`}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2 text-sm">
          <User className="h-3 w-3 text-muted-foreground" />
          <span>{patientName}</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <Stethoscope className="h-3 w-3 text-muted-foreground" />
          <span>{doctorName}</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <Calendar className="h-3 w-3 text-muted-foreground" />
          <span>{format(date, "MMM dd, yyyy")}</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <Clock className="h-3 w-3 text-muted-foreground" />
          <span>{format(date, "hh:mm a")}</span>
        </div>
        {notes && (
          <p className="text-sm text-muted-foreground pt-2 border-t border-border">
            {notes}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
