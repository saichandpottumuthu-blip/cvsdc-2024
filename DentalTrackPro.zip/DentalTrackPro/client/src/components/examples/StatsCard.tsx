import { StatsCard } from "../stats-card";
import { Users, Calendar, CheckCircle, TrendingUp } from "lucide-react";

export default function StatsCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-8">
      <StatsCard
        title="Total Patients"
        value="1,234"
        icon={Users}
        trend={{ value: "+12% from last month", isPositive: true }}
      />
      <StatsCard
        title="Today's Appointments"
        value="18"
        icon={Calendar}
        trend={{ value: "+3 from yesterday", isPositive: true }}
      />
      <StatsCard
        title="Completed Treatments"
        value="856"
        icon={CheckCircle}
        trend={{ value: "+8% this month", isPositive: true }}
      />
      <StatsCard
        title="Monthly Revenue"
        value="₹2.4L"
        icon={TrendingUp}
        trend={{ value: "+15% from last month", isPositive: true }}
      />
    </div>
  );
}
