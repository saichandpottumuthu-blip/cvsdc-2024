import { AppointmentCard } from "../appointment-card";

export default function AppointmentCardExample() {
  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-8">
      <AppointmentCard
        id="1"
        patientName="Rajesh Kumar"
        doctorName="Dr. Sharma"
        treatmentType="Root Canal"
        date={tomorrow}
        status="upcoming"
        notes="First session of root canal treatment"
        onEdit={(id) => console.log("Edit appointment:", id)}
        onDelete={(id) => console.log("Delete appointment:", id)}
      />
      <AppointmentCard
        id="2"
        patientName="Priya Sharma"
        doctorName="Dr. Reddy"
        treatmentType="Teeth Cleaning"
        date={yesterday}
        status="completed"
        notes="Regular dental checkup and cleaning"
        onEdit={(id) => console.log("Edit appointment:", id)}
        onDelete={(id) => console.log("Delete appointment:", id)}
      />
      <AppointmentCard
        id="3"
        patientName="Mohammed Ali"
        doctorName="Dr. Patel"
        treatmentType="Tooth Extraction"
        date={today}
        status="cancelled"
        notes="Patient requested cancellation"
        onEdit={(id) => console.log("Edit appointment:", id)}
        onDelete={(id) => console.log("Delete appointment:", id)}
      />
    </div>
  );
}
