import { CalendarView } from "../calendar-view";

export default function CalendarViewExample() {
  const mockAppointments = [
    {
      id: "1",
      time: "09:00 AM",
      patientName: "Rajesh Kumar",
      treatmentType: "Root Canal",
      status: "upcoming" as const,
    },
    {
      id: "2",
      time: "11:30 AM",
      patientName: "Priya Sharma",
      treatmentType: "Teeth Cleaning",
      status: "upcoming" as const,
    },
    {
      id: "3",
      time: "02:00 PM",
      patientName: "Mohammed Ali",
      treatmentType: "Dental Checkup",
      status: "completed" as const,
    },
  ];

  return (
    <div className="p-8">
      <CalendarView appointments={mockAppointments} />
    </div>
  );
}
