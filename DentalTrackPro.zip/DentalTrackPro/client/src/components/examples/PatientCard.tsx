import { PatientCard } from "../patient-card";

export default function PatientCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-8">
      <PatientCard
        id="1"
        patientId="CVS00001"
        name="Rajesh Kumar"
        age={35}
        gender="Male"
        phone="9876543210"
        email="rajesh.kumar@email.com"
        address="123 MG Road, Hayathnagar"
        onEdit={(id) => console.log("Edit patient:", id)}
        onDelete={(id) => console.log("Delete patient:", id)}
        onViewDetails={(id) => console.log("View patient details:", id)}
      />
      <PatientCard
        id="2"
        patientId="CVS00002"
        name="Priya Sharma"
        age={28}
        gender="Female"
        phone="9123456789"
        email="priya.s@email.com"
        address="456 LB Nagar, Hyderabad"
        onEdit={(id) => console.log("Edit patient:", id)}
        onDelete={(id) => console.log("Delete patient:", id)}
        onViewDetails={(id) => console.log("View patient details:", id)}
      />
      <PatientCard
        id="3"
        patientId="CVS00003"
        name="Mohammed Ali"
        age={42}
        gender="Male"
        phone="9988776655"
        address="789 Koti, Hyderabad"
        onEdit={(id) => console.log("Edit patient:", id)}
        onDelete={(id) => console.log("Delete patient:", id)}
        onViewDetails={(id) => console.log("View patient details:", id)}
      />
    </div>
  );
}
