import { SearchBar } from "../search-bar";

export default function SearchBarExample() {
  return (
    <div className="p-8 space-y-4">
      <SearchBar
        placeholder="Search patients by name, phone, or treatment..."
        onSearch={(query) => console.log("Search query:", query)}
      />
      <SearchBar
        placeholder="Search appointments..."
        onSearch={(query) => console.log("Search query:", query)}
      />
    </div>
  );
}
