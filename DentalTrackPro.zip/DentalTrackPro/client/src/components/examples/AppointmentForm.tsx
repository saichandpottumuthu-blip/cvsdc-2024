import { AppointmentForm } from "../appointment-form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function AppointmentFormExample() {
  return (
    <div className="p-8 max-w-3xl">
      <Card>
        <CardHeader>
          <CardTitle>Schedule New Appointment</CardTitle>
        </CardHeader>
        <CardContent>
          <AppointmentForm
            onSubmit={(data) => console.log("Appointment created:", data)}
            onCancel={() => console.log("Form cancelled")}
          />
        </CardContent>
      </Card>
    </div>
  );
}
