import { AppSidebar } from "../app-sidebar";
import { SidebarProvider } from "@/components/ui/sidebar";

export default function AppSidebarExample() {
  const style = {
    "--sidebar-width": "20rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar />
        <div className="flex-1 p-8">
          <h2 className="text-2xl font-semibold">Main Content Area</h2>
          <p className="text-muted-foreground mt-2">The sidebar shows CVS Dental Care official logo and navigation menu.</p>
        </div>
      </div>
    </SidebarProvider>
  );
}
