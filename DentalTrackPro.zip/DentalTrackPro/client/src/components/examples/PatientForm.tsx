import { PatientForm } from "../patient-form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function PatientFormExample() {
  return (
    <div className="p-8 max-w-3xl">
      <Card>
        <CardHeader>
          <CardTitle>Add New Patient</CardTitle>
        </CardHeader>
        <CardContent>
          <PatientForm
            onSubmit={(data) => console.log("Form submitted:", data)}
            onCancel={() => console.log("Form cancelled")}
          />
        </CardContent>
      </Card>
    </div>
  );
}
