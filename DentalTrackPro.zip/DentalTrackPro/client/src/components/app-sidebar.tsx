import { LayoutDashboard, Users, Calendar, FileText, Settings, LogOut, Phone, Mail } from "lucide-react";
import { Link, useLocation } from "wouter";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import logoImage from "@assets/CVS DEntal Round LOGO (1)_1761764628622.png";

const menuItems = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { title: "Patients", url: "/patients", icon: Users },
  { title: "Appointments", url: "/appointments", icon: Calendar },
  { title: "Reports", url: "/reports", icon: FileText },
  { title: "Settings", url: "/settings", icon: Settings },
];

export function AppSidebar() {
  const [location] = useLocation();

  return (
    <Sidebar>
      <SidebarHeader className="p-4 bg-primary/5">
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <img src={logoImage} alt="CVS Dental Care" className="h-12 w-12 rounded-md" />
            <div>
              <h1 className="text-lg font-bold text-primary">CVS Dental Care</h1>
              <p className="text-xs font-medium text-primary/70">Crafting Vibrant Smiles</p>
            </div>
          </div>
          <p className="text-xs text-muted-foreground pl-1">Hayathnagar, Hyderabad</p>
          <div className="space-y-1.5 pt-2 border-t border-sidebar-border">
            <div className="flex items-center gap-2 text-xs">
              <Phone className="h-3.5 w-3.5 text-primary" />
              <span className="text-sidebar-foreground font-medium">7901403030</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <Mail className="h-3.5 w-3.5 text-primary" />
              <span className="text-sidebar-foreground">cvsdentalcare@gmail.com</span>
            </div>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={location === item.url}>
                    <Link href={item.url} data-testid={`link-${item.title.toLowerCase()}`}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-4 border-t border-sidebar-border">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-sidebar-foreground">Dr. Admin</p>
              <Badge variant="secondary" className="text-xs">Admin</Badge>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="w-full justify-start" data-testid="button-logout">
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
